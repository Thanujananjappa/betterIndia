This ZIP is a sample for NGO bulk upload.
Structure:
- people.csv  (or people.json)
- photos/      (photo files referenced in CSV/JSON)

CSV columns (required):
name, age, gender, status, description, lastSeenLocation, photoFileName, contactNumber, address

Example rows are provided. Use this structure when creating your own ZIP.